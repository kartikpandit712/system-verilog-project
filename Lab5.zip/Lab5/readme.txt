Lab_ 5

Group Members:
Abha Singh
Kartik Pandit

Lab5
       ///
          part1.cpp
          part2.cpp
          output_file
          report 
          read me