The lab1 submitted by Kartik Pandit.

all the files are it the zip folder with report.

