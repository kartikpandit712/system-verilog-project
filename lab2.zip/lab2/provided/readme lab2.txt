Kartik Pandit 
lab2zip.
      //  lab2
                // provided 
                     //hw
                     //sw
                      report lab2
                      
                       report is written as per my understanding of the code and bugs and which I tried to eplain in my wording. 