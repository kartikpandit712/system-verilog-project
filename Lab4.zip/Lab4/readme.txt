Group member Name: 
Abha Singh  
Kartik Pandit


We have successfully reached to the frequency of 242.6 MHz.
And also we confirmed design functionality with given testbench in ModelSim. Which passed all the testcases.